<?php
    $serveur="localhost";
    $bdd="air_france";
    $user="root";
    $mdp= "";
?>