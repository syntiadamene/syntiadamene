<div class="contacts.php">
	<h2>Contactez Air France</h2>
	<p>
		<br/>BESOIN D'AIDE POUR VOTRE RÉSERVATION ?
		<br/>Air France Service Line: +33 9 69 39 36 54
		<br/>Frais d’émission plus élevés par téléphone, en savoir plus
		<br/>Prix d'un appel local vers : France
		<br/>Langues parlées : français - anglais
		<br/>Horaires d'ouverture : Aujourd'hui (08:00 - 22:00)
		<br/>Du lundi au dimanche
		<br/>08:00 - 22:00
	</p>
</div>
